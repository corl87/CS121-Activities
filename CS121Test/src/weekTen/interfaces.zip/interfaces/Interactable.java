package weekTen.interfaces;

public interface Interactable {
    void login();
    void sendMessage(String message);
    void displayDetails();
}
