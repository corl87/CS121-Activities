package week12.Lab11;

import java.util.Scanner;

public class Menu {
    protected Scanner scr = new Scanner(System.in);
    protected Pokedex pokedex = new Pokedex();

    public void displayMenu(){
        System.out.println("******MENU******\nPlease make a selection \n1) Add a pokemon\n2) Remove a pokemon\n3) Display pokemon info\n4) Display all pokemon\n5) Exit");
        String input = scr.nextLine();
        while(!input.equals("5")){
            if(input.equals("1")){
                createPokemon();
            }else if(input.equals("2")){
                deletePokemon();
            }else if(input.equals("3")){
                displayPokemon();
            }else if(input.equals("4")){
                displayAllPokemon();
            }else {
                System.out.println("Invalid entry, try again");
            }
            System.out.println("******MENU******\nPlease make a selection \n1) Add a pokemon\n2) Remove a pokemon\n3) Display pokemon info\n4) Display all pokemon\n5) Exit");
            input = scr.nextLine();
            }
    }

    public void createPokemon(){
        System.out.println("Enter pokemon name and hp");
        String name = scr.nextLine();
        int hp = Integer.parseInt(scr.nextLine());
        Pokemon input = new Pokemon(name, hp);

        while(true){
            System.out.println("Enter the name of a move or q to exit");
            String moveName = scr.nextLine();
            if(moveName.equals("q")){
                break;
            }else{
                System.out.println("Enter the power and speed of the move");
                int power = scr.nextInt();
                int speed = scr.nextInt();
                scr.nextLine();
                Move newMove = new Move(moveName, power, speed);
                input.addMove(newMove);
            }
        }
        System.out.println("Pokemon added to pokedex, back to menu");
        pokedex.addPokemon(input);
    }
    public void deletePokemon(){
        System.out.println("Enter the name of the pokemon you wish to delete");
        String name = scr.nextLine();
        if(pokedex.getPokemon(name) == null) {
            System.out.println("Pokemon not found");
        }else {
            pokedex.removePokemon(pokedex.getPokemon(name));
            System.out.println("removed "+name);
        }
    }

    public void displayPokemon(){
        System.out.println("Enter the name of the pokemon you wish to display");
        String name = scr.nextLine();
        if(pokedex.getPokemon(name)==null){
            System.out.println("Pokemon not found");
        }else{
            System.out.println(pokedex.getPokemon(name));
        }
    }

    public void displayAllPokemon(){
        for(Pokemon i : pokedex.getAllPokemon()){
            System.out.println(i.toString());
        }
    }
}

